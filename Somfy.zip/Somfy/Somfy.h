//
// (C)opyright yoyolb - 2014/08/05
// Version 0.1
// modifs par clox 13/01/2015
// retour plus ou moins version initiale yoyolb et fabrication d'une library 2017/05/12
// 
// Tested with Arduino UNO and:
//   - RX module RR3-433 (433.92 MHz) => port A1  ... qui capte généralement le 433.42MHz !
//   - TX module RT4-433 (433.92 MHz) => port A0
//

#ifndef Somfy_h
#define Somfy_h

#include "Arduino.h"

class CCodecSomfyRTS {
  public:
    enum t_status {
      k_waiting_synchro,
      k_receiving_data,
      k_complete
    };
  
  private:
    byte _portEntree;
    byte _portSortie;
    byte _command;
    unsigned long _address;
    unsigned long _rollingCode;
    t_status pulse(word p);
    bool decode();

  public:
    CCodecSomfyRTS();
    void begin(byte portEntree, byte portSortie);
    boolean available();
    byte getCommand();
    unsigned long getAddress();
    unsigned long getRollingCode();
    bool transmit(byte cmd, unsigned long rollingCode, unsigned long adresse);
    
  protected:
    t_status _status;
    byte _cpt_synchro_hw;
    byte _cpt_bits;
    byte _previous_bit;
    bool _waiting_half_symbol;
    byte _payload[7];
};

#endif
